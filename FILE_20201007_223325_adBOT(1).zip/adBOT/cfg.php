<?php
/* Ambil Keys Disini ==> https://bit.ly/31EV62r */
$key = "Tg&Ttygd65hjjs7"; 
$useragent = " Mozilla/5.0 (Linux; Android 9; Redmi Note 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Mobile Safari/537.36";
$ssidzec = "86muaqqus76iq6sdk302qm88o3";
$ssidltc = "71o4ddrlt9raf7rimsaec054l1";
$ssiddoge = "nn05kd89qjsbffib9rh4bheko2";
$ssidbch = "i0l58q05inm21s1pd71orgmc12";
$ssideth = "h712gg7h5lc2sgqe9ituq7fck4";
$valsurf = "SAsurf=SAsurfVal";
